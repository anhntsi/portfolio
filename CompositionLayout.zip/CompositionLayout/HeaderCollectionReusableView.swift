//
//  HeaderCollectionReusableView.swift
//  CompositionLayout
//
//  Created by The Anh Nguyen on 22/10/2023.
//

import UIKit

class HeaderCollectionReusableView: UICollectionReusableView {

    @IBOutlet weak var textLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
