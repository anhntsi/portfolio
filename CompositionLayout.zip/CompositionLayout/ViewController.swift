//
//  ViewController.swift
//  CompositionLayout
//
//  Created by The Anh Nguyen on 20/10/2023.
//

import UIKit

enum ComponentType: Int {
    case type1
    case type2
    case type3
    case type4
    case type5
}

struct Model {
    let title: String?
    let items: [Item]
    let type: ComponentType
}

struct Item {
    let id: String
}

class ViewController: BaseViewController {

    var datasource: [Model]!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        datasource = [
            Model(title: "New 1", items: [
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString)
            ], type: .type1),
            Model(title: "Recent 2", items: [
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString)
            ], type: .type2),
            Model(title: "Comming soon 3", items: [
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString),
                Item(id: UUID().uuidString)
            ], type: .type3),
        ]
    }
}
