//
//  CustomCollectionViewCell.swift
//  CompositionLayout
//
//  Created by The Anh Nguyen on 22/10/2023.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var widthConstraint: NSLayoutConstraint!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionView.setCollectionViewLayout(createLayout(), animated: true)
        collectionView.register(UINib(nibName: "DefaultCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
    }

    private func createLayout() -> UICollectionViewCompositionalLayout {
        let layout = UICollectionViewCompositionalLayout { [weak self]
            (sectionIndex: Int, layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            guard let self else { return nil }
            return self.customLayoutSection()
        }
        return layout
    }

    private func customLayoutSection() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 5)
        let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(100), heightDimension: .absolute(100))
        let firstGroup: NSCollectionLayoutGroup

        if #available(iOS 16.0, *) {
            firstGroup = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, repeatingSubitem: item, count: 3)
        } else {
            firstGroup = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 3)
        }
        firstGroup.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 5, trailing: 0)

        let secondGroup: NSCollectionLayoutGroup
        if #available(iOS 16.0, *) {
            secondGroup = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, repeatingSubitem: item, count: 7)
        } else {
            secondGroup = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 7)
        }
        let group = NSCollectionLayoutGroup.vertical(layoutSize: NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(200)), subitems: [firstGroup, secondGroup])

        let section = NSCollectionLayoutSection(group: group)

        widthConstraint.constant = 700
        heightConstraint.constant = 200

        return section
    }
}
